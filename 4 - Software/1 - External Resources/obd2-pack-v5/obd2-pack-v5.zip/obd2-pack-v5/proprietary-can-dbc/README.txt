This collection of DBC files for cars (incl. EVs) are downloaded from the sources listed here:
https://www.csselectronics.com/pages/can-dbc-file-database-intro#public-dbc-files

Note that these DBC files are mostly based on reverse engineering, meaning the quality may wary.

We always recommend to review the data decoded with this type of DBC files to ensure the validity.

Note also that we have only included DBC files - not e.g. CSV files that contain decoding info (see the list in our link above).